This is a candidate's document submission form where the candidate fills all his/her personal
details and submit for verification.
Kindly follow the below task notes.

1. All fields are mandatory which are marked with stars.
2. Date of birth: Minimum age should be 18 years.

3. If the “Same as Residential” mark is checked then the permanent
   address(Stree1 and street2) should not be mandatory. If not marked then
   permanent address should be mandatory.
4. Minimum two documents are required with all details like “File name”, “Type of
   file(image, pdf)” and file.
5. Document should be validated according to selected type of file.
   Note:
6. Create APIs using “Nodejs” and implement in “ReactJs” for the above task.
7. Only use below technologies..
   ● Backend Framework: ExpressJs
   ● Database: MongoDB
   ● Frontend: ReactJs

   CAUTION

   If sameAsResidential field is set to true, you must provide a value for permanentAddress to avoid crashing the server

   REQUIREMENT/DEPENDENCIES
   Express
   mongoose
   dotenv
   nodemon(optional for development)
